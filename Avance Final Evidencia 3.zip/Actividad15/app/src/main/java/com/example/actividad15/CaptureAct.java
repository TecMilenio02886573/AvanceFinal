package com.example.actividad15;
import com.journeyapps.barcodescanner.CaptureActivity;
public class CaptureAct extends CaptureActivity {
}
