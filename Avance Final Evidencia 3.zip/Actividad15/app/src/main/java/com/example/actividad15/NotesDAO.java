package com.example.actividad15;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.SQLException;
public class NotesDAO {

    private SQLiteDatabase database;
    private DatabaseHelper dbHelper;

    public NotesDAO(Context context){
        dbHelper= new DatabaseHelper(context);
    }

    public void open() throws SQLException{
        database= dbHelper.getWritableDatabase();
    }

    public void close(){
        dbHelper.close();
    }

    public long createNote(String title,String content){
      ContentValues values = new ContentValues();
      values.put(DatabaseHelper.COLUMN_TITLE,title);
      values.put(DatabaseHelper.COLUMN_CONTENT,content);
      return database.insert(DatabaseHelper.TABLE_NAME,null,values);
    }

    public Cursor readNotes(){
        String [] allColumns={DatabaseHelper.COLUMN_ID,DatabaseHelper.COLUMN_TITLE,
                DatabaseHelper.COLUMN_CONTENT};
        return database.query(DatabaseHelper.TABLE_NAME,allColumns,
                null,null,null,null,null);
    }

    public int updateNote(long id, String title, String content){
        ContentValues values = new ContentValues();
        values.put(DatabaseHelper.COLUMN_TITLE,title);
        values.put(DatabaseHelper.COLUMN_CONTENT,content);
        return database.update(DatabaseHelper.TABLE_NAME,values,
                DatabaseHelper.COLUMN_ID+"="+id,null);
    }

    public void deleteNote(long id){
        database.delete(DatabaseHelper.TABLE_NAME,
                DatabaseHelper.COLUMN_ID+"="+id,null);
    }

}
