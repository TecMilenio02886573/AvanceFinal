package com.example.actividad15;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddEditNote extends AppCompatActivity {

    private NotesDAO notesDAO;
    private long noteId=-1;

    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_edit_note);

        notesDAO= new NotesDAO(this);
        notesDAO.open();

        EditText noteTitle=findViewById(R.id.noteTitle);
        EditText noteContent=findViewById(R.id.noteContent);
        Button saveButton=findViewById(R.id.saveButton);
        Button deleteButton=findViewById(R.id.deleteButton);

        Intent intent=getIntent();
        noteId=intent.getLongExtra("noteId",-1);

        if(noteId!=-1){
            Cursor cursor= notesDAO.readNotes();
            if(cursor.moveToFirst()){
                do{
                    if(cursor.getLong(cursor.getColumnIndex(DatabaseHelper.COLUMN_ID))==noteId){
                        noteTitle.setText(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_TITLE)));
                        break;
                    }
                }while(cursor.moveToNext());
            }
            deleteButton.setVisibility(View.VISIBLE);
        }

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(noteId==-1){
                    notesDAO.createNote(
                            noteTitle.getText().toString(),
                            noteContent.getText().toString()
                    );
                }else{
                    notesDAO.updateNote(
                            noteId,
                            noteTitle.getText().toString(),
                            noteContent.getText().toString()
                    );
                }
                finish();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(noteId!=-1){
                    notesDAO.deleteNote(noteId);
                    finish();
                }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        notesDAO.close();
    }
}