package com.example.actividad15;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.database.Cursor;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.view.View;
import android.widget.Toast;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class MainActivity extends AppCompatActivity {
    private NotesDAO notesDAO;
    private SimpleCursorAdapter adapter;
    Button btn_scan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        notesDAO=new NotesDAO(this);
        notesDAO.open();

        ListView listView=findViewById(R.id.listView);
        Button addbutton=findViewById(R.id.addButton);
        btn_scan=findViewById(R.id.scanButton);
        btn_scan.setOnClickListener(v -> {scanCode();});


        Cursor cursor= notesDAO.readNotes();
        String [] from= new String[]{DatabaseHelper.COLUMN_TITLE,DatabaseHelper.COLUMN_CONTENT};
        int [] to=new int[]{R.id.noteTitle,R.id.noteContent};

        adapter= new SimpleCursorAdapter(this,R.layout.list_item,cursor,from,to,0);
        listView.setAdapter(adapter);

        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,AddEditNote.class));
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent= new Intent(MainActivity.this,AddEditNote.class);
                intent.putExtra("noteId",id);
                startActivity(intent);
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void scanCode(){
        ScanOptions options=new ScanOptions();
        options.setPrompt("Volume up to flash up");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(CaptureAct.class);
        barLaucher.launch(options);
    }

    ActivityResultLauncher<ScanOptions> barLaucher=registerForActivityResult(new ScanContract(), result->{
        if (result.getContents() != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Result");
            builder.setMessage(result.getContents());

            builder.setPositiveButton("Ok", (dialogInterface, which) -> dialogInterface.dismiss());

            // Botón para copiar el texto al portapapeles
            builder.setNegativeButton("Copiar", (dialogInterface, which) -> {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("QR Code", result.getContents());
                clipboard.setPrimaryClip(clip);
                Toast.makeText(MainActivity.this, "Texto copiado al portapapeles", Toast.LENGTH_SHORT).show();
            });

            builder.show();
        }
    });

    @Override
    protected void onResume(){
        super.onResume();
        adapter.changeCursor(notesDAO.readNotes());
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        notesDAO.close();
    }
}